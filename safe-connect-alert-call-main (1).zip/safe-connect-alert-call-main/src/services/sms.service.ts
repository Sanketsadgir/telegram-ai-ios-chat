
import { Capacitor } from '@capacitor/core';
import { locationService } from './location.service';
import { toast } from '@/components/ui/use-toast';

class SmsService {
  async sendEmergencySMS(phoneNumbers: string[]): Promise<void> {
    try {
      // Get current location and speed data
      const location = await locationService.getCurrentLocation();
      const speedData = locationService.getSpeedData();
      const timestamp = new Date().toLocaleString();
      const locationUrl = locationService.getGoogleMapsLink(location);
      
      const message = this.formatEmergencyMessage(timestamp, location, speedData, locationUrl);
      
      if (Capacitor.isNativePlatform()) {
        // For native platforms, we'd use a native SMS plugin
        console.log('Sending SMS to:', phoneNumbers, 'with message:', message);
        
        // This would require installing @capacitor/sms or similar plugin
        // await SMS.send({
        //   numbers: phoneNumbers,
        //   text: message,
        // });
        
        // For now, simulate sending
        for (const number of phoneNumbers) {
          console.log(`SMS sent to ${number}:`, message);
        }
        
        toast({
          title: 'Emergency SMS Sent',
          description: `Detailed emergency SMS sent to ${phoneNumbers.length} contact(s)`,
        });
      } else {
        // For web, show what would be sent
        console.log('Would send SMS to:', phoneNumbers);
        console.log('Message content:', message);
        
        // Create SMS links for each number
        phoneNumbers.forEach(number => {
          const smsUrl = `sms:${number}?body=${encodeURIComponent(message)}`;
          window.open(smsUrl, '_blank');
        });
        
        toast({
          title: 'SMS Links Opened',
          description: `SMS composition opened for ${phoneNumbers.length} contact(s)`,
        });
      }
    } catch (error) {
      console.error('Error sending emergency SMS:', error);
      toast({
        title: 'SMS Send Failed',
        description: 'Failed to send emergency SMS messages',
        variant: 'destructive',
      });
      throw error;
    }
  }

  private formatEmergencyMessage(timestamp: string, location: any, speedData: any, locationUrl: string): string {
    let message = `🚨 EMERGENCY: Accident detected at ${timestamp}\n\n`;
    message += `📍 Location: ${locationUrl}\n`;
    message += `GPS: ${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}\n`;
    message += `Accuracy: ${location.accuracy?.toFixed(1)}m\n\n`;
    
    if (speedData) {
      message += `🏎️ Speed Data:\n`;
      message += `Current: ${(speedData.currentSpeed * 3.6).toFixed(1)} km/h\n`;
      message += `Before: ${(speedData.speedBeforeAccident * 3.6).toFixed(1)} km/h\n`;
      message += `After: ${(speedData.speedAfterAccident * 3.6).toFixed(1)} km/h\n\n`;
    }
    
    message += `⚠️ Automated emergency alert - respond immediately!`;
    
    return message;
  }
}

export const smsService = new SmsService();
