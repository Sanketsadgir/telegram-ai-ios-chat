
import { BleClient, BleDevice, dataViewToText } from '@capacitor-community/bluetooth-le';

// UUID for ESP32 service and characteristic
const ESP32_SERVICE_UUID = '4fafc201-1fb5-459e-8fcc-c5c9c331914b';
const ESP32_CHARACTERISTIC_UUID = 'beb5483e-36e1-4688-b7f5-ea07361b26a8';

class BluetoothService {
  private device: BleDevice | null = null;
  private isConnected = false;
  private alertCallback: ((isAlert: boolean) => void) | null = null;

  async initialize(): Promise<void> {
    try {
      await BleClient.initialize();
      console.log('Bluetooth initialized successfully');
    } catch (error) {
      console.error('Error initializing Bluetooth:', error);
      throw error;
    }
  }

  async connectToDevice(device: BleDevice, onAlert: (isAlert: boolean) => void): Promise<boolean> {
    try {
      await BleClient.connect(
        device.deviceId,
        (deviceId) => this.onDeviceDisconnected(deviceId)
      );
      
      this.device = device;
      this.isConnected = true;
      this.alertCallback = onAlert;

      // Start notifications for accident alerts
      await this.startNotifications();
      
      console.log('Connected to device:', device.name);
      return true;
    } catch (error) {
      console.error('Error connecting to device:', error);
      this.isConnected = false;
      return false;
    }
  }

  private async startNotifications(): Promise<void> {
    if (!this.device || !this.isConnected) {
      throw new Error('No device connected');
    }

    try {
      await BleClient.startNotifications(
        this.device.deviceId,
        ESP32_SERVICE_UUID,
        ESP32_CHARACTERISTIC_UUID,
        (value) => {
          const text = dataViewToText(value);
          console.log('Received notification:', text);
          
          // Check if it's an accident alert
          const isAccident = text.includes('ACCIDENT') || text.includes('ALERT') || text === '1';
          
          // Notify the app
          if (this.alertCallback) {
            this.alertCallback(isAccident);
          }
        }
      );
      
      console.log('Started notifications for accident alerts');
    } catch (error) {
      console.error('Error starting notifications:', error);
      throw error;
    }
  }

  private async onDeviceDisconnected(deviceId: string): Promise<void> {
    console.log('Device disconnected:', deviceId);
    this.isConnected = false;
    this.device = null;
  }

  async disconnect(): Promise<void> {
    if (this.device && this.isConnected) {
      try {
        await BleClient.disconnect(this.device.deviceId);
        this.isConnected = false;
        this.device = null;
        console.log('Disconnected from device');
      } catch (error) {
        console.error('Error disconnecting from device:', error);
      }
    }
  }

  getConnectedDevice(): BleDevice | null {
    return this.device;
  }

  isDeviceConnected(): boolean {
    return this.isConnected;
  }
}

export const bluetoothService = new BluetoothService();
