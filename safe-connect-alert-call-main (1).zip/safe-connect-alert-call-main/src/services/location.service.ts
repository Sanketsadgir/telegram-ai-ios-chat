
import { Capacitor } from '@capacitor/core';

interface Location {
  latitude: number;
  longitude: number;
  accuracy?: number;
  timestamp?: number;
  speed?: number;
  heading?: number;
  altitude?: number;
}

interface SpeedData {
  currentSpeed: number;
  speedBeforeAccident: number;
  speedAfterAccident: number;
  timestamp: number;
}

class LocationService {
  private lastKnownLocation: Location | null = null;
  private speedHistory: number[] = [];
  private watchId: number | null = null;
  private isTracking: boolean = false;
  private speedData: SpeedData | null = null;

  async initialize(): Promise<void> {
    try {
      await this.requestLocationPermissions();
      await this.startLocationTracking();
      console.log('Location service initialized with tracking');
    } catch (error) {
      console.error('Error initializing location service:', error);
      throw error;
    }
  }

  async requestLocationPermissions(): Promise<boolean> {
    try {
      if (Capacitor.isNativePlatform()) {
        console.log('Requesting location permissions');
        return true;
      } else {
        if (!navigator.geolocation) {
          throw new Error('Geolocation not supported');
        }
        return true;
      }
    } catch (error) {
      console.error('Error requesting location permissions:', error);
      return false;
    }
  }

  async startLocationTracking(): Promise<void> {
    if (this.isTracking) return;

    try {
      if (navigator.geolocation) {
        this.watchId = navigator.geolocation.watchPosition(
          (position) => {
            const location: Location = {
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              accuracy: position.coords.accuracy,
              speed: position.coords.speed || 0,
              heading: position.coords.heading || 0,
              altitude: position.coords.altitude || 0,
              timestamp: position.timestamp
            };
            
            this.lastKnownLocation = location;
            this.updateSpeedHistory(location.speed || 0);
            console.log('Location updated:', location);
          },
          (error) => {
            console.error('Location tracking error:', error);
          },
          {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 5000
          }
        );
        
        this.isTracking = true;
        console.log('Location tracking started');
      }
    } catch (error) {
      console.error('Error starting location tracking:', error);
    }
  }

  private updateSpeedHistory(speed: number): void {
    this.speedHistory.push(speed);
    if (this.speedHistory.length > 10) {
      this.speedHistory.shift();
    }
  }

  recordAccidentSpeeds(): SpeedData {
    const currentSpeed = this.lastKnownLocation?.speed || 0;
    const speedBeforeAccident = this.speedHistory.length >= 3 
      ? this.speedHistory[this.speedHistory.length - 3] 
      : currentSpeed;
    
    this.speedData = {
      currentSpeed,
      speedBeforeAccident,
      speedAfterAccident: 0,
      timestamp: Date.now()
    };

    setTimeout(() => {
      if (this.speedData) {
        this.speedData.speedAfterAccident = this.lastKnownLocation?.speed || 0;
      }
    }, 5000);

    return this.speedData;
  }

  getSpeedData(): SpeedData | null {
    return this.speedData;
  }

  async getCurrentLocation(): Promise<Location> {
    if (this.lastKnownLocation) {
      return this.lastKnownLocation;
    }

    try {
      if (navigator.geolocation) {
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject, {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 5000
          });
        });

        this.lastKnownLocation = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          speed: position.coords.speed || 0,
          heading: position.coords.heading || 0,
          timestamp: position.timestamp
        };

        return this.lastKnownLocation;
      }
    } catch (error) {
      console.error('Error getting current location:', error);
    }

    return {
      latitude: 28.6139,
      longitude: 77.2090,
      timestamp: Date.now(),
      speed: 0
    };
  }

  getGoogleMapsLink(location: Location): string {
    return `https://maps.google.com/?q=${location.latitude},${location.longitude}`;
  }

  stopTracking(): void {
    if (this.watchId !== null && navigator.geolocation) {
      navigator.geolocation.clearWatch(this.watchId);
      this.watchId = null;
      this.isTracking = false;
      console.log('Location tracking stopped');
    }
  }
}

export const locationService = new LocationService();
