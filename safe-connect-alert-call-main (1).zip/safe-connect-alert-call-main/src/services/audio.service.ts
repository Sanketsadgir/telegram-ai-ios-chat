
import { Capacitor } from '@capacitor/core';

class AudioService {
  private audioElement: HTMLAudioElement | null = null;
  
  initialize() {
    if (!Capacitor.isNativePlatform()) {
      // For web, preload the audio file
      this.audioElement = new Audio('/emergency-alert.mp3');
      this.audioElement.preload = 'auto';
    } else {
      // For native, we would use Capacitor audio plugin
      console.log('Audio service initialized for native platform');
    }
  }
  
  async playEmergencyAlert() {
    try {
      console.log('Playing emergency alert sound');
      
      if (!Capacitor.isNativePlatform() && this.audioElement) {
        // For web
        this.audioElement.currentTime = 0;
        await this.audioElement.play();
      } else {
        // For native, we would use Capacitor audio plugin
        console.log('Would play alert sound on native platform');
        // Native implementation would go here
      }
    } catch (error) {
      console.error('Error playing emergency alert sound:', error);
    }
  }
  
  stopEmergencyAlert() {
    try {
      console.log('Stopping emergency alert sound');
      
      if (!Capacitor.isNativePlatform() && this.audioElement) {
        // For web
        this.audioElement.pause();
        this.audioElement.currentTime = 0;
      } else {
        // For native, we would use Capacitor audio plugin
        console.log('Would stop alert sound on native platform');
        // Native implementation would go here
      }
    } catch (error) {
      console.error('Error stopping emergency alert sound:', error);
    }
  }
}

export const audioService = new AudioService();
