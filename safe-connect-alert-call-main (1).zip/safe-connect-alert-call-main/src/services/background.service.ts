import { Capacitor } from '@capacitor/core';
import { locationService } from './location.service';
import { callService } from './call.service';
import { smsService } from './sms.service';
import { whatsappService } from './whatsapp.service';

interface BackgroundTaskConfig {
  enableLocationTracking: boolean;
  enableEmergencyResponse: boolean;
  emergencyContacts: string[];
}

class BackgroundService {
  private isRegistered = false;
  private isMonitoring = false;
  private config: BackgroundTaskConfig | null = null;
  private backgroundTaskId: number | null = null;

  async initialize(config: BackgroundTaskConfig) {
    this.config = config;
    
    if (Capacitor.isNativePlatform()) {
      try {
        // Register background task for native platforms
        await this.registerBackgroundTask();
        console.log('Background service initialized');
        this.isRegistered = true;
      } catch (error) {
        console.error('Error initializing background service:', error);
      }
    } else {
      // For web, use Page Visibility API and Service Workers
      this.setupWebBackgroundHandling();
      console.log('Web background service initialized');
      this.isRegistered = true;
    }
  }

  private async registerBackgroundTask(): Promise<void> {
    // In a real implementation, this would use Capacitor background plugins
    // such as @capacitor/background-task or custom native code
    console.log('Registering background task for continuous monitoring');
    
    // Simulate background task registration
    this.backgroundTaskId = Date.now();
  }

  private setupWebBackgroundHandling(): void {
    // Handle page visibility changes
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        console.log('App went to background - maintaining essential services');
        this.maintainEssentialServices();
      } else {
        console.log('App returned to foreground');
      }
    });

    // Register service worker for background processing
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .then(registration => {
          console.log('Service Worker registered:', registration);
        })
        .catch(error => {
          console.log('Service Worker registration failed:', error);
        });
    }
  }

  private maintainEssentialServices(): void {
    // Keep location tracking active
    if (this.config?.enableLocationTracking) {
      locationService.startLocationTracking();
    }
  }

  async startBackgroundMonitoring(): Promise<void> {
    if (!this.isRegistered || this.isMonitoring) return;

    try {
      this.isMonitoring = true;
      
      // Start continuous location tracking
      if (this.config?.enableLocationTracking) {
        await locationService.startLocationTracking();
      }

      // Set up periodic health checks
      this.startHealthCheckInterval();
      
      console.log('Background monitoring started');
    } catch (error) {
      console.error('Error starting background monitoring:', error);
    }
  }

  private startHealthCheckInterval(): void {
    // Check system health every 30 seconds
    setInterval(() => {
      this.performHealthCheck();
    }, 30000);
  }

  private performHealthCheck(): void {
    console.log('Background health check - services running');
    
    // Ensure location tracking is still active
    if (this.config?.enableLocationTracking) {
      const location = locationService.getCurrentLocation();
      console.log('Location service status: active');
    }
  }

  async handleEmergencyInBackground(emergencyContacts: string[]): Promise<void> {
    if (!this.isMonitoring) return;

    try {
      console.log('Handling emergency in background mode');
      
      // Record accident speeds
      locationService.recordAccidentSpeeds();
      
      // Wait a moment for speed data to be recorded
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Execute emergency protocols
      const primaryContact = emergencyContacts[0];
      
      if (primaryContact) {
        // Make emergency call
        await callService.makeAutomatedCall(primaryContact);
        
        // Send SMS to all contacts
        await smsService.sendEmergencySMS(emergencyContacts);
        
        // Send WhatsApp messages
        await whatsappService.sendEmergencyWhatsApp(emergencyContacts);
      }
      
      console.log('Emergency response completed in background');
    } catch (error) {
      console.error('Error handling emergency in background:', error);
    }
  }

  async stopBackgroundMonitoring(): Promise<void> {
    if (!this.isMonitoring) return;

    try {
      this.isMonitoring = false;
      
      // Stop location tracking
      locationService.stopTracking();
      
      // Clean up background task
      if (this.backgroundTaskId && Capacitor.isNativePlatform()) {
        // In real implementation, this would clean up native background task
        console.log('Cleaning up background task');
      }
      
      console.log('Background monitoring stopped');
    } catch (error) {
      console.error('Error stopping background monitoring:', error);
    }
  }

  isBackgroundMonitoringActive(): boolean {
    return this.isMonitoring;
  }

  isBackgroundMonitoringSupported(): boolean {
    return this.isRegistered;
  }
}

export const backgroundService = new BackgroundService();
