
import { locationService } from './location.service';
import { toast } from '@/components/ui/use-toast';

class WhatsAppService {
  private twilioAccountSid: string = 'AC657aaf9023fece07c85fb3c2e29faba2';
  private twilioAuthToken: string = 'b9b80353e0479e66ddd3f78b66e25398';
  private twilioWhatsAppNumber: string = '+14155238886';

  initialize(accountSid?: string, authToken?: string, whatsappNumber?: string) {
    // Use provided credentials or fall back to hardcoded ones
    if (accountSid && authToken && whatsappNumber) {
      this.twilioAccountSid = accountSid;
      this.twilioAuthToken = authToken;
      this.twilioWhatsAppNumber = whatsappNumber;
    }
    console.log('WhatsApp service initialized with Twilio credentials');
  }

  async sendEmergencyWhatsApp(phoneNumbers: string[]): Promise<void> {
    try {
      const location = await locationService.getCurrentLocation();
      const speedData = locationService.getSpeedData();
      const timestamp = new Date().toLocaleString();
      const mapsLink = locationService.getGoogleMapsLink(location);

      const message = this.formatEmergencyMessage(timestamp, location, speedData, mapsLink);

      for (const phoneNumber of phoneNumbers) {
        await this.sendWhatsAppMessage(phoneNumber, message);
      }

      toast({
        title: 'WhatsApp Emergency Sent',
        description: `Emergency WhatsApp messages sent to ${phoneNumbers.length} contact(s)`,
      });
    } catch (error) {
      console.error('Error sending WhatsApp emergency:', error);
      toast({
        title: 'WhatsApp Send Failed',
        description: 'Failed to send emergency WhatsApp messages',
        variant: 'destructive',
      });
    }
  }

  private formatEmergencyMessage(timestamp: string, location: any, speedData: any, mapsLink: string): string {
    let message = `🚨 EMERGENCY ALERT 🚨\n\n`;
    message += `⚠️ Accident detected by Veronica system at: ${timestamp}\n\n`;
    message += `📍 Location coordinates: ${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}\n`;
    message += `🗺️ View location: ${mapsLink}\n`;
    message += `📡 GPS accuracy: ${location.accuracy?.toFixed(1)}m\n\n`;
    
    if (speedData) {
      message += `🏎️ Speed at time of accident: ${(speedData.currentSpeed * 3.6).toFixed(1)} km/h\n`;
      message += `📈 Speed before accident: ${(speedData.speedBeforeAccident * 3.6).toFixed(1)} km/h\n`;
      message += `📉 Speed after accident: ${(speedData.speedAfterAccident * 3.6).toFixed(1)} km/h\n\n`;
    }
    
    message += `⚠️ This is an automated emergency alert from accident detection system. Please respond immediately.`;
    
    return message;
  }

  private async sendWhatsAppMessage(phoneNumber: string, message: string): Promise<void> {
    try {
      const url = `https://api.twilio.com/2010-04-01/Accounts/${this.twilioAccountSid}/Messages.json`;
      
      const formData = new FormData();
      formData.append('From', `whatsapp:${this.twilioWhatsAppNumber}`);
      formData.append('To', `whatsapp:${phoneNumber}`);
      formData.append('Body', message);

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${btoa(`${this.twilioAccountSid}:${this.twilioAuthToken}`)}`,
        },
        body: formData
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`WhatsApp send failed: ${response.statusText} - ${errorText}`);
      }

      const result = await response.json();
      console.log(`WhatsApp message sent to ${phoneNumber}. SID: ${result.sid}`);
    } catch (error) {
      console.error(`Error sending WhatsApp to ${phoneNumber}:`, error);
      throw error;
    }
  }

  // Test method to verify credentials
  async testConnection(): Promise<boolean> {
    try {
      await this.sendWhatsAppMessage('+918530276913', '👋 Test message from Veronica accident detection system');
      return true;
    } catch (error) {
      console.error('Test connection failed:', error);
      return false;
    }
  }
}

export const whatsappService = new WhatsAppService();
