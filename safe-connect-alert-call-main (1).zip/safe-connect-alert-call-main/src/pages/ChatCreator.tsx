
import React from 'react';
import ChatFeedbackCreator from '@/components/ChatFeedbackCreator';

const ChatCreator = () => {
  return <ChatFeedbackCreator />;
};

export default ChatCreator;
