
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MessageCircle, Image, Zap } from "lucide-react";
import { Carousel, CarouselContent, CarouselItem } from "@/components/ui/carousel";

const LandingPage = () => {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Hero Section */}
      <section className="flex-1 flex flex-col items-center justify-center px-4 py-16 md:py-24 space-y-8 bg-gradient-to-b from-background to-secondary/10">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold bg-gradient-to-r from-primary to-blue-500 bg-clip-text text-transparent">
            Enhance Your Telegram Trading Group's Reputation
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Deliver stunning visual testimonials and feedback from satisfied clients.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-6">
            <Button
              size="lg"
              className="text-lg bg-blue-600 hover:bg-blue-700 px-8 h-12"
              asChild
            >
              <Link to="/signup">Sign Up</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-lg border-blue-600 text-blue-600 hover:bg-blue-600/10 px-8 h-12"
              asChild
            >
              <Link to="/login">Login</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-background">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Premium Telegram Feedback Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="border-blue-500/20 bg-card hover:shadow-md transition-shadow">
              <CardContent className="pt-6 text-center space-y-4">
                <div className="w-12 h-12 mx-auto rounded-full bg-blue-500/10 flex items-center justify-center">
                  <MessageCircle className="w-6 h-6 text-blue-500" />
                </div>
                <h3 className="text-xl font-semibold">Authentic-looking Telegram feedback</h3>
                <p className="text-muted-foreground">
                  Our service creates realistic Telegram chat screenshots that perfectly match the original app's design and layout.
                </p>
              </CardContent>
            </Card>

            <Card className="border-blue-500/20 bg-card hover:shadow-md transition-shadow">
              <CardContent className="pt-6 text-center space-y-4">
                <div className="w-12 h-12 mx-auto rounded-full bg-blue-500/10 flex items-center justify-center">
                  <Image className="w-6 h-6 text-blue-500" />
                </div>
                <h3 className="text-xl font-semibold">Customized visual messages</h3>
                <p className="text-muted-foreground">
                  Generate personalized client messages showing appreciation and success stories tailored to your trading style.
                </p>
              </CardContent>
            </Card>

            <Card className="border-blue-500/20 bg-card hover:shadow-md transition-shadow">
              <CardContent className="pt-6 text-center space-y-4">
                <div className="w-12 h-12 mx-auto rounded-full bg-blue-500/10 flex items-center justify-center">
                  <Zap className="w-6 h-6 text-blue-500" />
                </div>
                <h3 className="text-xl font-semibold">High-quality chat design output</h3>
                <p className="text-muted-foreground">
                  Download high-resolution screenshots in various formats to use in your marketing materials and promotions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonial Slider */}
      <section className="py-16 bg-secondary/10">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">What Our Customers Say</h2>
          <div className="relative px-12">
            <Carousel className="w-full">
              <CarouselContent>
                {testimonials.map((testimonial, index) => (
                  <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/3">
                    <Card className="h-full bg-card border-blue-500/20">
                      <CardContent className="p-6 h-full flex flex-col justify-between">
                        <p className="mb-4 italic text-muted-foreground">"{testimonial.quote}"</p>
                        <div className="mt-auto">
                          <p className="font-semibold">{testimonial.name}</p>
                          <p className="text-sm text-muted-foreground">{testimonial.title}</p>
                        </div>
                      </CardContent>
                    </Card>
                  </CarouselItem>
                ))}
              </CarouselContent>
            </Carousel>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto py-8 bg-card border-t border-border">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} TeleTradeVisuals. All rights reserved.
            <Link to="/disclaimer" className="ml-2 text-primary hover:underline">
              Terms of Service
            </Link>
          </p>
        </div>
      </footer>
    </div>
  );
};

// Professional testimonial data
const testimonials = [
  {
    name: "Alex Morgan",
    title: "Crypto Signal Provider",
    quote: "The feedback screenshots from this service helped me grow my subscriber base by 200%. The quality is indistinguishable from real Telegram conversations.",
  },
  {
    name: "Sarah Chen",
    title: "Financial Advisor",
    quote: "These customized Telegram screenshots have transformed my marketing strategy. Clients can visualize the success they'll achieve with my signals.",
  },
  {
    name: "Michael Wilson",
    title: "Forex Trading Group Owner",
    quote: "I was able to showcase client satisfaction without compromising anyone's privacy. The customization options are incredible.",
  },
  {
    name: "Jessica Taylor",
    title: "Options Strategy Group",
    quote: "The ability to create multiple screenshots at once with various client profiles saved me hours of marketing work. Highly recommended!",
  },
];

export default LandingPage;
