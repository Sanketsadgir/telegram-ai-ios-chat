
import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Bluetooth, BellRing, Settings, Shield, AlertTriangle, MessageSquare } from 'lucide-react';
import { bluetoothService } from '@/services/bluetooth.service';
import { callService } from '@/services/call.service';
import { smsService } from '@/services/sms.service';
import { whatsappService } from '@/services/whatsapp.service';
import { locationService } from '@/services/location.service';
import { audioService } from '@/services/audio.service';
import { backgroundService } from '@/services/background.service';
import ConnectionStatus from '@/components/ConnectionStatus';
import BluetoothScanner from '@/components/BluetoothScanner';
import EmergencySettings, { EmergencyContact } from '@/components/EmergencySettings';
import AlertStatus from '@/components/AlertStatus';
import { BleDevice } from '@capacitor-community/bluetooth-le';

const EMERGENCY_CALL_DELAY = 10;

const Index = () => {
  // Emergency contacts state
  const [emergencyContacts, setEmergencyContacts] = useState<EmergencyContact[]>(() => {
    const savedContacts = localStorage.getItem('emergencyContacts');
    if (savedContacts) {
      try {
        return JSON.parse(savedContacts);
      } catch (e) {
        console.error('Failed to parse saved contacts', e);
      }
    }
    return [{ 
      id: '1', 
      name: 'Emergency Contact', 
      number: '+918530276913',
      isPrimary: true
    }];
  });
  
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [connectedDevice, setConnectedDevice] = useState<BleDevice | null>(null);
  const [isAlertActive, setIsAlertActive] = useState<boolean>(false);
  const [countdownValue, setCountdownValue] = useState<number | null>(null);
  const [showSettings, setShowSettings] = useState<boolean>(false);
  
  // Initialize services on component mount
  useEffect(() => {
    const initServices = async () => {
      try {
        await bluetoothService.initialize();
        await locationService.initialize();
        audioService.initialize();
        
        // Initialize WhatsApp service with hardcoded credentials
        whatsappService.initialize();
        
        await backgroundService.initialize({
          enableLocationTracking: true,
          enableEmergencyResponse: true,
          emergencyContacts: emergencyContacts.map(c => c.number)
        });
        
        await backgroundService.startBackgroundMonitoring();
        
        console.log('All services initialized successfully');
      } catch (error) {
        console.error('Failed to initialize services:', error);
        toast({
          title: 'Initialization Error',
          description: 'Failed to initialize one or more services. Some features may not work properly.',
          variant: 'destructive',
        });
      }
    };
    
    initServices();
    
    return () => {
      if (isConnected) {
        bluetoothService.disconnect();
      }
      backgroundService.stopBackgroundMonitoring();
      locationService.stopTracking();
    };
  }, []);
  
  useEffect(() => {
    localStorage.setItem('emergencyContacts', JSON.stringify(emergencyContacts));
  }, [emergencyContacts]);
  
  const handleAccidentAlert = useCallback((isAccident: boolean) => {
    if (isAccident && !isAlertActive) {
      setIsAlertActive(true);
      
      locationService.recordAccidentSpeeds();
      
      toast({
        title: 'ACCIDENT DETECTED!',
        description: 'Emergency services will be contacted automatically.',
        variant: 'destructive',
      });
      
      audioService.playEmergencyAlert();
      
      setCountdownValue(EMERGENCY_CALL_DELAY);
      
      const interval = setInterval(() => {
        setCountdownValue((prev) => {
          if (prev === null) return null;
          if (prev <= 1) {
            clearInterval(interval);
            handleEmergencyActions();
            return null;
          }
          return prev - 1;
        });
      }, 1000);
      
      if (backgroundService.isBackgroundMonitoringActive()) {
        const contactNumbers = emergencyContacts.map(c => c.number);
        backgroundService.handleEmergencyInBackground(contactNumbers);
      }
      
      return () => clearInterval(interval);
    }
  }, [isAlertActive, emergencyContacts]);
  
  const handleDeviceSelected = async (device: BleDevice) => {
    try {
      const connected = await bluetoothService.connectToDevice(device, handleAccidentAlert);
      
      if (connected) {
        setIsConnected(true);
        setConnectedDevice(device);
        toast({
          title: 'Connected',
          description: `Connected to ${device.name || 'ESP32 Device'}`,
        });
      } else {
        toast({
          title: 'Connection Failed',
          description: 'Failed to connect to the device. Please try again.',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Error connecting to device:', error);
      toast({
        title: 'Connection Error',
        description: 'An error occurred while connecting to the device.',
        variant: 'destructive',
      });
    }
  };
  
  const handleDisconnect = async () => {
    try {
      await bluetoothService.disconnect();
      setIsConnected(false);
      setConnectedDevice(null);
      toast({
        title: 'Disconnected',
        description: 'Disconnected from ESP32 device',
      });
    } catch (error) {
      console.error('Error disconnecting:', error);
    }
  };
  
  const handleEmergencyActions = async () => {
    const primaryContact = emergencyContacts.find(contact => contact.isPrimary);
    const contactNumbers = emergencyContacts.map(contact => contact.number);
    
    if (primaryContact) {
      try {
        await callService.makeAutomatedCall(primaryContact.number);
        await smsService.sendEmergencySMS(contactNumbers);
        await whatsappService.sendEmergencyWhatsApp(contactNumbers);
        
        console.log('All emergency protocols executed');
      } catch (error) {
        console.error('Error executing emergency actions:', error);
      }
    } else if (emergencyContacts.length > 0) {
      try {
        await callService.makeAutomatedCall(emergencyContacts[0].number);
        await smsService.sendEmergencySMS(contactNumbers);
        await whatsappService.sendEmergencyWhatsApp(contactNumbers);
      } catch (error) {
        console.error('Error executing emergency actions:', error);
      }
    } else {
      toast({
        title: 'No Emergency Contacts',
        description: 'Please set up emergency contacts in settings.',
        variant: 'destructive',
      });
    }
  };
  
  const handleEmergencyCall = () => {
    const primaryContact = emergencyContacts.find(contact => contact.isPrimary);
    
    if (primaryContact) {
      callService.makeAutomatedCall(primaryContact.number);
    } else if (emergencyContacts.length > 0) {
      callService.makeAutomatedCall(emergencyContacts[0].number);
    } else {
      toast({
        title: 'No Emergency Number',
        description: 'Please set an emergency contact number in settings.',
        variant: 'destructive',
      });
    }
  };
  
  const handleSendSMS = async () => {
    if (emergencyContacts.length > 0) {
      const contactNumbers = emergencyContacts.map(contact => contact.number);
      await smsService.sendEmergencySMS(contactNumbers);
    } else {
      toast({
        title: 'No Emergency Contacts',
        description: 'Please add emergency contacts in settings.',
        variant: 'destructive',
      });
    }
  };
  
  const handleSendWhatsApp = async () => {
    if (emergencyContacts.length > 0) {
      const contactNumbers = emergencyContacts.map(contact => contact.number);
      await whatsappService.sendEmergencyWhatsApp(contactNumbers);
    } else {
      toast({
        title: 'No Emergency Contacts',
        description: 'Please add emergency contacts in settings.',
        variant: 'destructive',
      });
    }
  };
  
  const handleDismissAlert = () => {
    setIsAlertActive(false);
    setCountdownValue(null);
    audioService.stopEmergencyAlert();
  };
  
  const handleSaveEmergencyContacts = (contacts: EmergencyContact[]) => {
    setEmergencyContacts(contacts);
    setShowSettings(false);
  };

  const testWhatsApp = async () => {
    const success = await whatsappService.testConnection();
    if (success) {
      toast({
        title: 'WhatsApp Test Successful',
        description: 'Test message sent successfully',
      });
    } else {
      toast({
        title: 'WhatsApp Test Failed',
        description: 'Failed to send test message',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="px-4 py-6 bg-white shadow-sm">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <Shield className="h-8 w-8 text-alert mr-2" />
            <h1 className="font-bold text-xl">Veronica Safety Alert</h1>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="icon" onClick={() => setShowSettings(!showSettings)}>
              <Settings className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-6 max-w-md">
        {showSettings ? (
          <div className="mb-6">
            <EmergencySettings 
              emergencyContacts={emergencyContacts}
              onSaveContacts={handleSaveEmergencyContacts}
            />
            <div className="mt-4">
              <Button
                variant="outline"
                className="w-full"
                onClick={() => setShowSettings(false)}
              >
                Back to Main Screen
              </Button>
            </div>
          </div>
        ) : (
          <>
            <AlertStatus 
              isAlertActive={isAlertActive}
              onCallEmergency={handleEmergencyCall}
              onSendSMS={handleSendSMS}
              onDismissAlert={handleDismissAlert}
              countdown={countdownValue}
            />
            
            {isAlertActive && (
              <div className="mb-4">
                <Button
                  variant="outline"
                  className="w-full border-green-500 text-green-500 hover:bg-green-50"
                  onClick={handleSendWhatsApp}
                >
                  <MessageSquare className="h-4 w-4 mr-2" /> Send WhatsApp Emergency
                </Button>
              </div>
            )}
            
            <div className="mb-4">
              <ConnectionStatus 
                isConnected={isConnected}
                deviceName={connectedDevice?.name || null}
              />
            </div>
            
            {isConnected ? (
              <Button
                variant="outline"
                className="w-full mb-4 border-bluetooth text-bluetooth"
                onClick={handleDisconnect}
              >
                <Bluetooth className="mr-2 h-4 w-4" /> Disconnect from ESP32
              </Button>
            ) : (
              <BluetoothScanner onDeviceSelected={handleDeviceSelected} />
            )}
            
            <div className="mt-4 space-y-2">
              <Button
                variant="outline"
                className="w-full border-green-500 text-green-500"
                onClick={testWhatsApp}
              >
                <MessageSquare className="mr-2 h-4 w-4" /> Test WhatsApp Connection
              </Button>
            </div>
            
            {isConnected && (
              <div className="mt-6 border-t pt-4">
                <h3 className="text-sm font-medium mb-2">Testing</h3>
                <Button
                  variant="outline"
                  className="w-full mb-2 border-alert text-alert"
                  onClick={() => handleAccidentAlert(true)}
                >
                  <AlertTriangle className="mr-2 h-4 w-4" /> Simulate Accident Alert
                </Button>
              </div>
            )}
          </>
        )}
        
        <div className="mt-8 bg-white p-4 rounded-lg border text-sm">
          <h3 className="font-medium mb-2 flex items-center">
            <BellRing className="h-4 w-4 mr-1 text-alert" /> Veronica Enhanced Features
          </h3>
          <p className="text-muted-foreground text-xs mb-2">
            ✓ Automated emergency calling<br/>
            ✓ GPS location with speed data<br/>
            ✓ SMS with accident details<br/>
            ✓ WhatsApp via Twilio (offline)<br/>
            ✓ Background monitoring<br/>
            ✓ Real-time speed tracking
          </p>
          <p className="text-muted-foreground text-xs">
            The app runs continuously and automatically sends location,
            speed data, and emergency alerts when an accident is detected.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Index;
