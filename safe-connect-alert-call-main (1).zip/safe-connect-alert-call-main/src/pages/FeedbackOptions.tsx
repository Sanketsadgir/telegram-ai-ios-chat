
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  screenshots: z.string().min(1, {
    message: "Please select the number of screenshots.",
  }),
  deliveryTime: z.string().min(1, {
    message: "Please select delivery time.",
  }),
  platform: z.string().min(1, {
    message: "Please select a chat platform.",
  }),
  name: z.string().min(1, {
    message: "Please enter a name.",
  }),
  groupName: z.string().min(1, {
    message: "Please enter your group name.",
  }),
  tone: z.string().min(1, {
    message: "Please select a tone.",
  }),
});

const FeedbackOptions = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("demo");
  const [totalPrice, setTotalPrice] = useState(0);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      screenshots: "",
      deliveryTime: "",
      platform: "",
      name: "",
      groupName: "",
      tone: "",
    },
  });

  const calculatePrice = (screenshotCount: string, deliveryTime: string) => {
    // Base prices
    const basePrice = {
      "1": 10,
      "3": 25,
      "5": 40,
      "10": 70,
      "20+": 120,
    };

    const expeditedFee = {
      "1hour": 15,
      "3hours": 10,
      "24hours": 0,
    };

    const screenshots = screenshotCount as keyof typeof basePrice;
    const delivery = deliveryTime as keyof typeof expeditedFee;

    return basePrice[screenshots] + (expeditedFee[delivery] || 0);
  };

  const onValueChange = (field: string, value: string) => {
    if (field === "screenshots" || field === "deliveryTime") {
      const screenshots = field === "screenshots" ? value : form.getValues("screenshots");
      const deliveryTime = field === "deliveryTime" ? value : form.getValues("deliveryTime");
      
      if (screenshots && deliveryTime) {
        const price = calculatePrice(screenshots, deliveryTime);
        setTotalPrice(price);
      }
    }
  };

  const handleCheckout = (data: z.infer<typeof formSchema>) => {
    toast({
      title: "Order Submitted",
      description: `Your order for ${data.screenshots} screenshots has been received.`,
    });
    console.log("Form data:", data);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-6xl mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold mb-8">Feedback Options</h1>

        <Tabs defaultValue="demo" onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="demo">Demo Feedback</TabsTrigger>
            <TabsTrigger value="buy">Buy Feedback</TabsTrigger>
          </TabsList>

          <TabsContent value="demo" className="space-y-8 animate-in fade-in-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {demoExamples.map((example, index) => (
                <Card key={index} className="overflow-hidden">
                  <div className="aspect-[4/3] relative bg-zinc-100 dark:bg-zinc-800">
                    <img 
                      src={example.image} 
                      alt={example.title}
                      className="object-cover w-full h-full"
                    />
                  </div>
                  <CardHeader>
                    <CardTitle>{example.title}</CardTitle>
                    <CardDescription>{example.description}</CardDescription>
                  </CardHeader>
                  <CardFooter>
                    <Button variant="outline" className="w-full" onClick={() => setActiveTab("buy")}>
                      Get Similar
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
            <div className="flex justify-center">
              <Button size="lg" onClick={() => setActiveTab("buy")}>
                Create Custom Feedback
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="buy" className="animate-in fade-in-0">
            <Card>
              <CardHeader>
                <CardTitle>Custom Feedback Options</CardTitle>
                <CardDescription>
                  Configure your feedback screenshots with the options below.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(handleCheckout)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-6">
                        <h3 className="text-lg font-semibold">Order Details</h3>
                        
                        <FormField
                          control={form.control}
                          name="screenshots"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Number of Screenshots</FormLabel>
                              <Select 
                                onValueChange={(value) => {
                                  field.onChange(value);
                                  onValueChange("screenshots", value);
                                }}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select quantity" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="1">1 Screenshot</SelectItem>
                                  <SelectItem value="3">3 Screenshots</SelectItem>
                                  <SelectItem value="5">5 Screenshots</SelectItem>
                                  <SelectItem value="10">10 Screenshots</SelectItem>
                                  <SelectItem value="20+">20+ Screenshots</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                How many different screenshots you need.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="deliveryTime"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Delivery Time</FormLabel>
                              <Select 
                                onValueChange={(value) => {
                                  field.onChange(value);
                                  onValueChange("deliveryTime", value);
                                }}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select delivery time" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="1hour">1 Hour (Express)</SelectItem>
                                  <SelectItem value="3hours">3 Hours</SelectItem>
                                  <SelectItem value="24hours">24 Hours</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                How quickly you need the screenshots.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="platform"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Chat Platform</FormLabel>
                              <Select 
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select platform" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="telegram">Telegram</SelectItem>
                                  <SelectItem value="whatsapp">WhatsApp</SelectItem>
                                  <SelectItem value="instagram">Instagram DMs</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                Which platform your screenshots should match.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="space-y-6">
                        <h3 className="text-lg font-semibold">Customization Options</h3>
                        
                        <FormField
                          control={form.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Your Name</FormLabel>
                              <FormControl>
                                <Input placeholder="John Doe" {...field} />
                              </FormControl>
                              <FormDescription>
                                The name to use in the screenshots.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="groupName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Group Name</FormLabel>
                              <FormControl>
                                <Input placeholder="Elite Traders" {...field} />
                              </FormControl>
                              <FormDescription>
                                Your trading group's name.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="tone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Feedback Tone</FormLabel>
                              <Select 
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select tone" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="positive">Positive</SelectItem>
                                  <SelectItem value="skeptical">Skeptical to Convinced</SelectItem>
                                  <SelectItem value="amazed">Amazed</SelectItem>
                                  <SelectItem value="grateful">Grateful</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                The emotional tone of the feedback.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormItem>
                          <FormLabel>Upload Reference (Optional)</FormLabel>
                          <FormControl>
                            <Input type="file" />
                          </FormControl>
                          <FormDescription>
                            Upload images or documents as references.
                          </FormDescription>
                        </FormItem>
                      </div>
                    </div>

                    <Separator />

                    <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                      <div className="text-xl font-semibold">
                        Total Price: ${totalPrice.toFixed(2)}
                      </div>
                      <Button type="submit" size="lg" className="w-full md:w-auto">
                        Proceed to Checkout
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

// Demo examples data
const demoExamples = [
  {
    title: "Telegram Success Story",
    description: "A client sharing their success after following your trading signals.",
    image: "https://source.unsplash.com/featured/?chart",
  },
  {
    title: "WhatsApp Group Activity",
    description: "Active discussion showing engagement in your trading community.",
    image: "https://source.unsplash.com/featured/?trading",
  },
  {
    title: "New Member Testimonial",
    description: "A new member sharing their positive experience with the group.",
    image: "https://source.unsplash.com/featured/?crypto",
  },
];

export default FeedbackOptions;
