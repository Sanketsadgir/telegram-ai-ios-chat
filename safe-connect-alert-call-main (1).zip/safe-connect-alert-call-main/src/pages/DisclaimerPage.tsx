
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

const DisclaimerPage = () => {
  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-4">
      <Card className="max-w-3xl w-full border-blue-500/20">
        <CardHeader>
          <CardTitle className="text-2xl font-bold">Legal Disclaimer</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            <strong>Important Notice:</strong> All feedback, screenshots, and simulations provided by TradeCred are fictional and for entertainment/marketing demo purposes only.
          </p>
          
          <h3 className="text-lg font-semibold mt-6">Usage Terms</h3>
          <p>
            The content provided by TradeCred is intended solely for demonstration, educational, and marketing purposes. Any resemblance to real trading groups, conversations, or individuals is purely coincidental.
          </p>
          
          <h3 className="text-lg font-semibold mt-6">Legal Compliance</h3>
          <p>
            Users of TradeCred services agree to comply with all applicable laws and regulations in their jurisdiction regarding marketing practices, false advertising, and financial promotion. Users take full responsibility for how they use the content provided.
          </p>
          
          <h3 className="text-lg font-semibold mt-6">Non-Investment Advice</h3>
          <p>
            Nothing provided by TradeCred constitutes investment advice, financial advice, trading advice, or any other sort of advice. TradeCred is not responsible for any financial losses or gains resulting from the use of our content.
          </p>
          
          <h3 className="text-lg font-semibold mt-6">Not Financial Services</h3>
          <p>
            TradeCred is not a financial service provider, investment advisor, broker, or trader. We do not operate or manage any trading groups or provide financial advice of any kind.
          </p>
          
          <h3 className="text-lg font-semibold mt-6">No Guarantees</h3>
          <p>
            TradeCred makes no guarantees regarding the effectiveness of our content in helping users acquire clients, gain followers, or generate any form of income or profit.
          </p>
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button variant="outline" asChild>
            <Link to="/">Return to Home</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default DisclaimerPage;
