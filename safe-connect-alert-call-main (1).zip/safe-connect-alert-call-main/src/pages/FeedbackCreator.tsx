
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import { Upload } from "lucide-react";

const formSchema = z.object({
  context: z.string().min(10, {
    message: "Context must be at least 10 characters.",
  }),
  screenshots: z.number().min(1).max(10000),
  startTime: z.string(),
  endTime: z.string(),
  includeSignals: z.boolean().default(false),
  includeGratitude: z.boolean().default(false),
  includeDynamicProfiles: z.boolean().default(false),
});

const FeedbackCreator = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      context: "",
      screenshots: 5,
      startTime: "09:00",
      endTime: "17:00",
      includeSignals: true,
      includeGratitude: true,
      includeDynamicProfiles: true,
    },
  });

  const onSubmit = (data: z.infer<typeof formSchema>) => {
    console.log("Form data:", data);
    console.log("Uploaded files:", uploadedFiles);
    
    // Show loading toast
    toast({
      title: "Processing your request",
      description: "We're generating your Telegram screenshots. This may take a moment.",
    });
    
    // Simulate processing time 
    setTimeout(() => {
      // Redirect to the preview page
      navigate("/preview");
    }, 2000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setUploadedFiles((prev) => [...prev, ...newFiles]);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <Card className="border-blue-500/20">
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Telegram Feedback Creator</CardTitle>
            <CardDescription>
              Customize your Telegram feedback screenshots with the options below
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                <FormField
                  control={form.control}
                  name="context"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Context of Conversation</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe the scenario (e.g., 'clients thanking for win,' 'multiple users excited after a signal')"
                          className="min-h-[100px]"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        The more details you provide, the better the results.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="screenshots"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Number of Screenshots</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min={1} 
                            max={10000} 
                            {...field} 
                            onChange={e => field.onChange(parseInt(e.target.value))}
                          />
                        </FormControl>
                        <FormDescription>
                          Choose any quantity from 1 to 10,000
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="startTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Start Time</FormLabel>
                          <FormControl>
                            <Input type="time" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="endTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>End Time</FormLabel>
                          <FormControl>
                            <Input type="time" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                
                <div>
                  <FormLabel>Upload Sample Screenshots (optional)</FormLabel>
                  <div className="mt-2 border-2 border-dashed border-blue-500/30 rounded-md p-6 flex flex-col items-center justify-center bg-blue-500/5">
                    <Upload className="h-10 w-10 text-blue-500 mb-2" />
                    <p className="text-sm text-muted-foreground mb-2">
                      Drag and drop Telegram screenshots, or click to select
                    </p>
                    <Input
                      type="file"
                      multiple
                      accept="image/*"
                      className="hidden"
                      id="file-upload"
                      onChange={handleFileUpload}
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById("file-upload")?.click()}
                      className="border-blue-500/50 text-blue-500"
                    >
                      Select Files
                    </Button>
                    
                    {uploadedFiles.length > 0 && (
                      <div className="mt-4 w-full">
                        <p className="text-sm font-medium mb-2">{uploadedFiles.length} file(s) selected:</p>
                        <ul className="text-xs text-muted-foreground space-y-1">
                          {uploadedFiles.map((file, index) => (
                            <li key={index}>{file.name}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="includeSignals"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 p-4 border rounded-md">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Insert Trade Signal Images</FormLabel>
                          <FormDescription>
                            Add visually styled trade signals inline with messages
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="includeGratitude"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 p-4 border rounded-md">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Add Gratitude / Thank You Messages</FormLabel>
                          <FormDescription>
                            Include tailored chat-style appreciation messages
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="includeDynamicProfiles"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 p-4 border rounded-md">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Use Dynamic Client Profiles</FormLabel>
                          <FormDescription>
                            Create variation with unique client names and profile pictures
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                </div>
                
                <Button 
                  type="submit" 
                  size="lg"
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  Generate Screenshots
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default FeedbackCreator;
