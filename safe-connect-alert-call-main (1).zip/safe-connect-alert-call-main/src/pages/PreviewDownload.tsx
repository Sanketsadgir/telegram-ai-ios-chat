
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Download, RefreshCw, Check, X } from "lucide-react";

// Mock screenshot data for preview
const mockScreenshots = Array(8).fill(0).map((_, i) => ({
  id: i + 1,
  url: `https://picsum.photos/500/800?random=${i+1}`,
  selected: true,
}));

const PreviewDownload = () => {
  const { toast } = useToast();
  const [screenshots, setScreenshots] = useState(mockScreenshots);
  const [fileFormat, setFileFormat] = useState("png");
  const [quality, setQuality] = useState("standard");
  const [isProcessing, setIsProcessing] = useState(false);
  
  const handleDownloadAll = () => {
    toast({
      title: "Preparing your download",
      description: "Compressing all screenshots into a ZIP file...",
    });
    
    // Simulate download process
    setTimeout(() => {
      toast({
        title: "Download ready!",
        description: "Your screenshots have been successfully downloaded.",
      });
    }, 2000);
  };
  
  const handleDownloadSingle = (id: number) => {
    toast({
      title: "Downloading screenshot",
      description: `Screenshot #${id} is being downloaded...`,
    });
  };
  
  const handleReprocess = (id: number) => {
    setIsProcessing(true);
    toast({
      title: "Reprocessing screenshot",
      description: `Screenshot #${id} is being regenerated...`,
    });
    
    setTimeout(() => {
      setIsProcessing(false);
      toast({
        title: "Screenshot reprocessed",
        description: `Screenshot #${id} has been successfully regenerated.`,
      });
    }, 2000);
  };
  
  const toggleSelection = (id: number) => {
    setScreenshots(screenshots.map(shot => 
      shot.id === id ? {...shot, selected: !shot.selected} : shot
    ));
  };
  
  const selectedCount = screenshots.filter(s => s.selected).length;

  return (
    <div className="min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Preview & Download</h1>
          <p className="text-muted-foreground">
            Review your generated Telegram screenshots and download them in your preferred format.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {screenshots.map((screenshot) => (
                <Card 
                  key={screenshot.id} 
                  className={`overflow-hidden border ${
                    screenshot.selected 
                      ? "border-blue-500/50" 
                      : "border-border opacity-70"
                  }`}
                >
                  <div className="relative aspect-[9/16] bg-black/20">
                    <img 
                      src={screenshot.url} 
                      alt={`Screenshot ${screenshot.id}`} 
                      className="w-full h-full object-contain"
                    />
                    <div className="absolute top-2 right-2">
                      <Button 
                        variant="outline" 
                        size="icon"
                        onClick={() => toggleSelection(screenshot.id)}
                        className={`rounded-full ${
                          screenshot.selected 
                            ? "bg-blue-500 text-white border-none" 
                            : "bg-background/80"
                        }`}
                      >
                        {screenshot.selected ? (
                          <Check className="h-4 w-4" />
                        ) : (
                          <X className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                  <CardContent className="p-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Screenshot #{screenshot.id}</span>
                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="h-8 w-8 p-0" 
                          onClick={() => handleReprocess(screenshot.id)}
                        >
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="h-8 w-8 p-0"
                          onClick={() => handleDownloadSingle(screenshot.id)}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
          
          <div className="space-y-6">
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Download Options</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      {selectedCount} of {screenshots.length} screenshots selected
                    </p>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium mb-2">File Format</h4>
                      <Tabs 
                        defaultValue="png" 
                        className="w-full"
                        value={fileFormat}
                        onValueChange={setFileFormat}
                      >
                        <TabsList className="grid grid-cols-4 w-full">
                          <TabsTrigger value="png">PNG</TabsTrigger>
                          <TabsTrigger value="jpg">JPG</TabsTrigger>
                          <TabsTrigger value="webp">WebP</TabsTrigger>
                          <TabsTrigger value="pdf">PDF</TabsTrigger>
                        </TabsList>
                      </Tabs>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-medium mb-2">Quality</h4>
                      <RadioGroup 
                        defaultValue="standard"
                        value={quality}
                        onValueChange={setQuality}
                        className="flex gap-4"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="standard" id="standard" />
                          <Label htmlFor="standard">Standard</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="high" id="high" />
                          <Label htmlFor="high">High-res</Label>
                        </div>
                      </RadioGroup>
                    </div>
                  </div>
                  
                  <Button 
                    className="w-full bg-blue-600 hover:bg-blue-700"
                    onClick={handleDownloadAll}
                    disabled={selectedCount === 0}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Download {selectedCount} Screenshot{selectedCount !== 1 ? 's' : ''}
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => setScreenshots(screenshots.map(s => ({...s, selected: true})))}
                  >
                    Select All
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-blue-500/5 border-blue-500/20">
              <CardContent className="pt-6">
                <p className="text-sm">
                  Need to make adjustments? Return to the creator dashboard to modify your settings 
                  and generate new screenshots.
                </p>
                <Button 
                  variant="outline" 
                  className="mt-4 w-full border-blue-500/50 text-blue-500"
                  onClick={() => window.history.back()}
                >
                  Back to Creator
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PreviewDownload;
