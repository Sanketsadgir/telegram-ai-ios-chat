
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { MessageSquare, Settings } from 'lucide-react';
import { whatsappService } from '@/services/whatsapp.service';

interface TwilioSettingsProps {
  onSave: () => void;
}

const TwilioSettings = ({ onSave }: TwilioSettingsProps) => {
  const [accountSid, setAccountSid] = useState(() => 
    localStorage.getItem('twilioAccountSid') || ''
  );
  const [authToken, setAuthToken] = useState(() => 
    localStorage.getItem('twilioAuthToken') || ''
  );
  const [whatsappNumber, setWhatsappNumber] = useState(() => 
    localStorage.getItem('twilioWhatsAppNumber') || ''
  );
  const { toast } = useToast();

  const handleSave = () => {
    if (!accountSid || !authToken || !whatsappNumber) {
      toast({
        title: 'Missing Information',
        description: 'Please fill in all Twilio configuration fields',
        variant: 'destructive',
      });
      return;
    }

    // Save to localStorage
    localStorage.setItem('twilioAccountSid', accountSid);
    localStorage.setItem('twilioAuthToken', authToken);
    localStorage.setItem('twilioWhatsAppNumber', whatsappNumber);

    // Initialize WhatsApp service
    whatsappService.initialize(accountSid, authToken, whatsappNumber);

    toast({
      title: 'Twilio Settings Saved',
      description: 'WhatsApp emergency messaging is now configured',
    });

    onSave();
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-lg flex items-center">
          <MessageSquare className="mr-2 h-5 w-5 text-green-500" /> WhatsApp Configuration
        </CardTitle>
        <CardDescription>
          Configure Twilio for WhatsApp emergency messaging
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          <div className="space-y-2">
            <Label htmlFor="accountSid">Twilio Account SID</Label>
            <Input
              id="accountSid"
              placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
              value={accountSid}
              onChange={(e) => setAccountSid(e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="authToken">Twilio Auth Token</Label>
            <Input
              id="authToken"
              type="password"
              placeholder="Your Twilio Auth Token"
              value={authToken}
              onChange={(e) => setAuthToken(e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="whatsappNumber">Twilio WhatsApp Number</Label>
            <Input
              id="whatsappNumber"
              placeholder="+14155238886"
              value={whatsappNumber}
              onChange={(e) => setWhatsappNumber(e.target.value)}
            />
          </div>
          
          <div className="text-sm text-muted-foreground">
            <p>💡 To get these credentials:</p>
            <p>1. Sign up at twilio.com</p>
            <p>2. Enable WhatsApp Sandbox</p>
            <p>3. Copy your Account SID and Auth Token</p>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={handleSave} className="w-full bg-green-500 hover:bg-green-600">
          Save WhatsApp Settings
        </Button>
      </CardFooter>
    </Card>
  );
};

export default TwilioSettings;
