
import React from 'react';
import { cn } from '@/lib/utils';

interface ChatBubbleProps {
  message: string;
  timestamp: string;
  isOutgoing: boolean;
  senderName?: string;
  avatar?: string;
}

const ChatBubble: React.FC<ChatBubbleProps> = ({
  message,
  timestamp,
  isOutgoing,
  senderName,
  avatar
}) => {
  return (
    <div className={cn(
      "flex mb-2 px-4",
      isOutgoing ? "justify-end" : "justify-start"
    )}>
      <div className={cn(
        "flex max-w-[85%] items-end",
        isOutgoing ? "flex-row-reverse" : "flex-row"
      )}>
        {!isOutgoing && (
          <div className="w-8 h-8 rounded-full bg-gray-300 mr-2 mb-1 flex-shrink-0 overflow-hidden">
            {avatar ? (
              <img src={avatar} alt={senderName} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-blue-500 flex items-center justify-center text-white font-medium text-xs">
                {senderName?.[0]?.toUpperCase() || 'U'}
              </div>
            )}
          </div>
        )}
        <div className={cn(
          "relative px-3 py-2 shadow-sm max-w-[280px] min-w-[60px]",
          isOutgoing 
            ? "bg-[#007AFF] text-white rounded-[18px] rounded-br-[4px] ml-2" 
            : "bg-[#F1F1F4] text-black rounded-[18px] rounded-bl-[4px] mr-2"
        )}>
          <p className="text-[16px] leading-[1.35] break-words font-normal">{message}</p>
          <div className={cn(
            "text-[12px] mt-1 float-right ml-2 flex items-center gap-1",
            isOutgoing ? "text-white/70" : "text-gray-500"
          )}>
            <span className="font-normal">{timestamp}</span>
            {isOutgoing && (
              <div className="flex ml-1">
                <svg width="12" height="8" viewBox="0 0 12 8" fill="currentColor" className="opacity-70">
                  <path d="M5.5 5.5L9 2l.5.5L5.5 6.5 2 3l.5-.5L5.5 5.5z"/>
                  <path d="M10.5 5.5L14 2l.5.5L10.5 6.5 7 3l.5-.5L10.5 5.5z" transform="translate(-2.5 0)"/>
                </svg>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatBubble;
