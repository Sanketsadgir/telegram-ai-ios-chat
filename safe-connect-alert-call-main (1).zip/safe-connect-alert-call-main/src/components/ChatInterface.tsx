
import React, { useState } from 'react';
import ChatBubble from './ChatBubble';
import { ArrowLeft, Phone, Video, Search, Paperclip, Send, Smile } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface ChatMessage {
  id: string;
  message: string;
  timestamp: string;
  isOutgoing: boolean;
  senderName?: string;
  avatar?: string;
}

interface ChatInterfaceProps {
  messages: ChatMessage[];
  contactName: string;
  contactAvatar?: string;
  onBack?: () => void;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({
  messages,
  contactName,
  contactAvatar,
  onBack
}) => {
  const [inputValue, setInputValue] = useState('');

  return (
    <div className="flex flex-col h-full bg-white relative">
      {/* iOS Status Bar */}
      <div className="bg-white px-4 py-1 flex justify-between items-center text-black text-[15px] font-medium border-b border-gray-100">
        <span>9:41</span>
        <div className="flex items-center gap-1">
          <div className="flex gap-1">
            <div className="w-1 h-1 bg-black rounded-full"></div>
            <div className="w-1 h-1 bg-black rounded-full"></div>
            <div className="w-1 h-1 bg-black rounded-full"></div>
            <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
          </div>
          <svg className="w-6 h-4 ml-1" viewBox="0 0 24 16" fill="none">
            <rect x="1" y="3" width="22" height="10" rx="2" stroke="black" strokeWidth="1" fill="none"/>
            <rect x="23" y="6" width="1" height="4" rx="0.5" fill="black"/>
          </svg>
        </div>
      </div>

      {/* Chat Header */}
      <div className="bg-[#F7F7F7] border-b border-gray-200 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center">
          {onBack && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onBack}
              className="text-[#007AFF] hover:bg-gray-100 mr-2 p-1 font-medium"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
          )}
          <div className="w-8 h-8 rounded-full bg-gray-300 mr-3 overflow-hidden">
            {contactAvatar ? (
              <img src={contactAvatar} alt={contactName} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-[#007AFF] flex items-center justify-center text-white font-medium text-sm">
                {contactName[0]?.toUpperCase()}
              </div>
            )}
          </div>
          <div>
            <h3 className="font-medium text-[17px] text-black">{contactName}</h3>
            <p className="text-gray-500 text-[13px] font-normal">last seen recently</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button variant="ghost" size="sm" className="text-[#007AFF] hover:bg-gray-100 p-1">
            <Search className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="sm" className="text-[#007AFF] hover:bg-gray-100 p-1">
            <Phone className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto py-3 bg-white">
        {messages.map((message) => (
          <ChatBubble
            key={message.id}
            message={message.message}
            timestamp={message.timestamp}
            isOutgoing={message.isOutgoing}
            senderName={message.senderName}
            avatar={message.avatar}
          />
        ))}
      </div>

      {/* Input Area */}
      <div className="bg-[#F7F7F7] px-4 py-2 flex items-center gap-2 border-t border-gray-200">
        <Button variant="ghost" size="sm" className="text-gray-600 hover:bg-gray-200 p-2">
          <Paperclip className="h-5 w-5" />
        </Button>
        <div className="flex-1 bg-white rounded-[20px] px-4 py-2 flex items-center border border-gray-300">
          <Input 
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Message" 
            className="border-0 focus-visible:ring-0 bg-transparent text-[16px] placeholder:text-gray-500 p-0 h-auto font-normal"
          />
          <Button variant="ghost" size="sm" className="text-gray-600 hover:bg-gray-200 p-1 ml-2">
            <Smile className="h-4 w-4" />
          </Button>
        </div>
        <Button variant="ghost" size="sm" className="text-[#007AFF] hover:bg-gray-200 p-2">
          <Send className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );
};

export default ChatInterface;
