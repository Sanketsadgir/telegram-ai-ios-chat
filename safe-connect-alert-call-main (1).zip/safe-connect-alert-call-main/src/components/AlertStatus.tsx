
import React, { useEffect, useState } from 'react';
import { AlertTriangle, Phone, PhoneCall, AlertCircle, MessageSquare } from 'lucide-react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { audioService } from '@/services/audio.service';

interface AlertStatusProps {
  isAlertActive: boolean;
  onCallEmergency: () => void;
  onSendSMS: () => void;
  onDismissAlert: () => void;
  countdown: number | null;
}

const AlertStatus = ({ isAlertActive, onCallEmergency, onSendSMS, onDismissAlert, countdown }: AlertStatusProps) => {
  const [showAnimation, setShowAnimation] = useState(false);

  useEffect(() => {
    if (isAlertActive) {
      setShowAnimation(true);
      audioService.playEmergencyAlert();
      const timeout = setTimeout(() => {
        setShowAnimation(false);
      }, 500);
      return () => clearTimeout(timeout);
    } else {
      audioService.stopEmergencyAlert();
    }
  }, [isAlertActive]);

  return (
    <Card className={cn(
      "w-full mb-4 overflow-hidden transition-all duration-300",
      isAlertActive ? "border-alert bg-alert-light" : "border-muted bg-card",
      showAnimation && "animate-shake"
    )}>
      <CardHeader className={cn(
        "pb-2",
        isAlertActive && "bg-alert text-white"
      )}>
        <CardTitle className="flex items-center justify-between text-lg">
          <span className="flex items-center">
            {isAlertActive ? (
              <AlertCircle className="h-5 w-5 mr-2 animate-pulse" />
            ) : (
              <AlertTriangle className="h-5 w-5 mr-2 text-muted-foreground" />
            )}
            {isAlertActive ? "ACCIDENT DETECTED!" : "Monitoring for Accidents"}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className={cn("pt-4", isAlertActive && "text-alert-dark")}>
        {isAlertActive ? (
          <div className="text-center">
            <div className="flex items-center justify-center mb-4">
              <div className={cn(
                "w-24 h-24 rounded-full flex items-center justify-center",
                "bg-alert text-white animate-pulse-alert"
              )}>
                <AlertTriangle className="h-12 w-12" />
              </div>
            </div>
            {countdown !== null && (
              <p className="text-lg font-bold mb-2">
                Emergency services in: <span className="text-alert text-xl">{countdown}</span> seconds
              </p>
            )}
            <p className="font-medium">An accident has been detected by your ESP32 device.</p>
            <p className="mt-2 text-sm">
              Emergency contacts will be automatically notified with your current location.
            </p>
          </div>
        ) : (
          <p className="text-center text-muted-foreground">
            Your ESP32 device will send an alert here if an accident is detected.
          </p>
        )}
      </CardContent>
      {isAlertActive && (
        <CardFooter className="flex flex-col gap-2">
          <div className="flex w-full space-x-2">
            <Button 
              className="flex-1 bg-alert hover:bg-alert-dark" 
              onClick={onCallEmergency}
            >
              <PhoneCall className="h-4 w-4 mr-1" /> Call Emergency Now
            </Button>
            <Button 
              variant="outline" 
              className="flex-1 border-alert text-alert hover:bg-alert-light" 
              onClick={onSendSMS}
            >
              <MessageSquare className="h-4 w-4 mr-1" /> Send SOS SMS
            </Button>
          </div>
          <Button 
            variant="outline" 
            className="w-full border-alert text-alert hover:bg-alert-light" 
            onClick={onDismissAlert}
          >
            Dismiss Alert
          </Button>
        </CardFooter>
      )}
    </Card>
  );
};

export default AlertStatus;
