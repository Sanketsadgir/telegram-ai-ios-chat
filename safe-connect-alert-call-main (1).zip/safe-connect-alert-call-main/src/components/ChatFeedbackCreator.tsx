import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { Plus, Download, Eye, MessageSquare } from 'lucide-react';
import ChatInterface from './ChatInterface';

const formSchema = z.object({
  contactName: z.string().min(2, 'Contact name must be at least 2 characters'),
  messageText: z.string().min(1, 'Message cannot be empty'),
  timestamp: z.string().min(1, 'Timestamp is required'),
  isOutgoing: z.boolean(),
});

interface ChatMessage {
  id: string;
  message: string;
  timestamp: string;
  isOutgoing: boolean;
  senderName?: string;
  avatar?: string;
}

const ChatFeedbackCreator = () => {
  const { toast } = useToast();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      message: 'Hey! I just wanted to say thank you for the amazing service. Everything was perfect!',
      timestamp: '2:14 PM',
      isOutgoing: false,
      senderName: 'Sarah'
    },
    {
      id: '2',
      message: 'Thank you so much! We really appreciate your feedback 😊',
      timestamp: '2:15 PM',
      isOutgoing: true
    },
    {
      id: '3',
      message: 'The quality exceeded my expectations and the delivery was super fast. Will definitely recommend to friends!',
      timestamp: '2:16 PM',
      isOutgoing: false,
      senderName: 'Sarah'
    },
    {
      id: '4',
      message: 'That means a lot to us! Thank you for choosing our service ❤️',
      timestamp: '2:17 PM',
      isOutgoing: true
    }
  ]);
  
  const [contactName, setContactName] = useState('Sarah Johnson');
  const [previewMode, setPreviewMode] = useState(false);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      contactName: 'Sarah',
      messageText: '',
      timestamp: new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }),
      isOutgoing: false,
    },
  });

  const onSubmit = (data: z.infer<typeof formSchema>) => {
    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      message: data.messageText,
      timestamp: data.timestamp,
      isOutgoing: data.isOutgoing,
      senderName: data.isOutgoing ? 'You' : data.contactName
    };
    
    setMessages([...messages, newMessage]);
    setContactName(data.contactName);
    
    // Reset form
    form.setValue('messageText', '');
    form.setValue('timestamp', new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }));
    
    toast({
      title: 'Message Added',
      description: 'New message added to the chat conversation'
    });
  };

  const generateScreenshot = () => {
    toast({
      title: 'Screenshot Generated',
      description: 'Chat screenshot has been created and is ready for download'
    });
  };

  const clearMessages = () => {
    setMessages([]);
    toast({
      title: 'Chat Cleared',
      description: 'All messages have been removed'
    });
  };

  if (previewMode) {
    return (
      <div className="h-screen bg-black flex items-center justify-center">
        <div className="w-[375px] h-[812px] bg-white relative overflow-hidden rounded-[40px] shadow-2xl">
          <ChatInterface
            messages={messages}
            contactName={contactName}
            onBack={() => setPreviewMode(false)}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-2">Telegram Chat Creator</h1>
          <p className="text-gray-600">Create realistic Telegram conversations for testimonials and feedback</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Chat Creator Form */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MessageSquare className="mr-2 h-5 w-5" />
                Create Messages
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="contactName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contact Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter contact name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="messageText"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Message Text</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Enter the message content..."
                            className="min-h-[100px]"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="timestamp"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Timestamp</FormLabel>
                          <FormControl>
                            <Input placeholder="2:30 PM" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="isOutgoing"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Message Type</FormLabel>
                          <FormControl>
                            <select 
                              className="w-full p-2 border rounded-md"
                              value={field.value ? 'outgoing' : 'incoming'}
                              onChange={(e) => field.onChange(e.target.value === 'outgoing')}
                            >
                              <option value="incoming">Incoming (Client)</option>
                              <option value="outgoing">Outgoing (You)</option>
                            </select>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <Button type="submit" className="w-full">
                    <Plus className="mr-2 h-4 w-4" />
                    Add Message
                  </Button>
                </form>
              </Form>
              
              <div className="mt-6 space-y-2">
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => setPreviewMode(true)}
                >
                  <Eye className="mr-2 h-4 w-4" />
                  Preview iPhone ({messages.length} messages)
                </Button>
                
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={generateScreenshot}
                >
                  <Download className="mr-2 h-4 w-4" />
                  Generate Screenshot
                </Button>
                
                <Button 
                  variant="destructive" 
                  className="w-full"
                  onClick={clearMessages}
                >
                  Clear All Messages
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Chat Preview */}
          <Card className="lg:h-[600px]">
            <CardHeader>
              <CardTitle>Live Preview</CardTitle>
            </CardHeader>
            <CardContent className="p-0 h-full">
              <div className="h-full bg-gray-100 rounded-lg overflow-hidden border">
                <ChatInterface
                  messages={messages}
                  contactName={contactName}
                />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ChatFeedbackCreator;
