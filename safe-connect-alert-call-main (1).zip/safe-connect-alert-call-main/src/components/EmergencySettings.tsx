import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { Phone, Plus, Trash2, User } from 'lucide-react';

export interface EmergencyContact {
  id: string;
  name: string;
  number: string;
  isPrimary: boolean;
}

interface EmergencySettingsProps {
  emergencyContacts: EmergencyContact[];
  onSaveContacts: (contacts: EmergencyContact[]) => void;
}

const EmergencySettings = ({ emergencyContacts, onSaveContacts }: EmergencySettingsProps) => {
  const [contacts, setContacts] = useState<EmergencyContact[]>(emergencyContacts);
  const [newName, setNewName] = useState('');
  const [newNumber, setNewNumber] = useState('');
  const { toast } = useToast();

  const handleAddContact = () => {
    if (!newNumber || newNumber.length < 3) {
      toast({
        title: 'Invalid Number',
        description: 'Please enter a valid emergency contact number',
        variant: 'destructive',
      });
      return;
    }
    
    const newContact: EmergencyContact = {
      id: Date.now().toString(),
      name: newName || `Contact ${contacts.length + 1}`,
      number: newNumber,
      isPrimary: contacts.length === 0, // First contact is primary by default
    };
    
    const updatedContacts = [...contacts, newContact];
    setContacts(updatedContacts);
    setNewName('');
    setNewNumber('');
    
    toast({
      title: 'Contact Added',
      description: `${newContact.name} has been added to your emergency contacts`,
    });
  };

  const handleRemoveContact = (id: string) => {
    const updatedContacts = contacts.filter(contact => contact.id !== id);
    
    // If we removed the primary contact, make the first contact primary
    if (updatedContacts.length > 0 && !updatedContacts.some(c => c.isPrimary)) {
      updatedContacts[0].isPrimary = true;
    }
    
    setContacts(updatedContacts);
    
    toast({
      title: 'Contact Removed',
      description: 'Emergency contact has been removed',
    });
  };

  const handleSetPrimary = (id: string) => {
    const updatedContacts = contacts.map(contact => ({
      ...contact,
      isPrimary: contact.id === id
    }));
    
    setContacts(updatedContacts);
    
    toast({
      title: 'Primary Contact Updated',
      description: 'Primary emergency contact has been updated',
    });
  };

  const handleSave = () => {
    if (contacts.length === 0) {
      toast({
        title: 'No Contacts',
        description: 'Please add at least one emergency contact',
        variant: 'destructive',
      });
      return;
    }
    
    onSaveContacts(contacts);
    toast({
      title: 'Settings Saved',
      description: 'Emergency contacts have been updated',
    });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-lg flex items-center">
          <Phone className="mr-2 h-5 w-5 text-alert" /> Emergency Contacts
        </CardTitle>
        <CardDescription>
          These numbers will be called and messaged automatically when an accident is detected
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          {/* Existing contacts */}
          {contacts.length > 0 && (
            <div className="space-y-2">
              <Label>Your Emergency Contacts</Label>
              {contacts.map(contact => (
                <div key={contact.id} className="flex items-center justify-between bg-gray-50 p-3 rounded-md">
                  <div>
                    <div className="flex items-center">
                      <User className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span className="font-medium">{contact.name}</span>
                      {contact.isPrimary && (
                        <span className="ml-2 text-xs bg-alert text-white px-2 py-0.5 rounded-full">Primary</span>
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground ml-6">{contact.number}</div>
                  </div>
                  <div className="flex gap-2">
                    {!contact.isPrimary && (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => handleSetPrimary(contact.id)}
                        className="h-8 text-xs"
                      >
                        Set Primary
                      </Button>
                    )}
                    <Button 
                      variant="outline" 
                      size="icon" 
                      onClick={() => handleRemoveContact(contact.id)}
                      className="h-8 w-8 text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Add new contact */}
          <div className="space-y-2">
            <Label>Add New Contact</Label>
            <div className="grid grid-cols-1 gap-2">
              <Input
                placeholder="Contact Name"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
              />
              <div className="flex gap-2">
                <Input
                  type="tel"
                  placeholder="Phone Number"
                  value={newNumber}
                  onChange={(e) => setNewNumber(e.target.value)}
                  className="flex-1"
                />
                <Button onClick={handleAddContact} size="icon">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={handleSave} className="w-full bg-alert hover:bg-alert-dark">Save Contacts</Button>
      </CardFooter>
    </Card>
  );
};

export default EmergencySettings;
