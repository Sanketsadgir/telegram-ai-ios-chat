
import React from 'react';
import { cn } from '@/lib/utils';

interface ConnectionStatusProps {
  isConnected: boolean;
  deviceName: string | null;
}

const ConnectionStatus = ({ isConnected, deviceName }: ConnectionStatusProps) => {
  return (
    <div className="flex items-center space-x-2 mb-4">
      <div 
        className={cn(
          "w-4 h-4 rounded-full", 
          isConnected ? "bg-status-connected animate-pulse" : "bg-status-disconnected"
        )}
      />
      <span className="font-medium">
        {isConnected 
          ? `Connected to ${deviceName || 'ESP32 Device'}`
          : 'Disconnected'
        }
      </span>
    </div>
  );
};

export default ConnectionStatus;
