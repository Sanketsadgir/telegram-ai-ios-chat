
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { BleClient, BleDevice, ScanResult } from '@capacitor-community/bluetooth-le';
import { Bluetooth, Loader2, RefreshCw, X } from 'lucide-react';

interface BluetoothScannerProps {
  onDeviceSelected: (device: BleDevice) => void;
}

const BluetoothScanner = ({ onDeviceSelected }: BluetoothScannerProps) => {
  const [isScanning, setIsScanning] = useState(false);
  const [devices, setDevices] = useState<ScanResult[]>([]);

  useEffect(() => {
    return () => {
      if (isScanning) {
        stopScan();
      }
    };
  }, [isScanning]);

  const startScan = async () => {
    try {
      setIsScanning(true);
      setDevices([]);
      
      await BleClient.initialize();
      
      await BleClient.requestLEScan(
        {
          services: [],
          namePrefix: 'ESP32',
          allowDuplicates: false,
        },
        (result) => {
          setDevices((prevDevices) => {
            // Check if device already exists
            const exists = prevDevices.some(
              (device) => device.device.deviceId === result.device.deviceId
            );
            if (!exists) {
              return [...prevDevices, result];
            }
            return prevDevices;
          });
        }
      );
      
      // Stop scanning after 10 seconds
      setTimeout(() => {
        stopScan();
      }, 10000);
    } catch (error) {
      console.error('Bluetooth scan error:', error);
      toast({
        title: 'Bluetooth Error',
        description: 'Failed to scan for devices. Please check if Bluetooth is enabled.',
        variant: 'destructive',
      });
      stopScan();
    }
  };

  const stopScan = async () => {
    try {
      await BleClient.stopLEScan();
    } catch (error) {
      console.error('Error stopping scan:', error);
    } finally {
      setIsScanning(false);
    }
  };

  const handleDeviceSelect = (device: BleDevice) => {
    onDeviceSelected(device);
    stopScan();
  };

  return (
    <Card className="w-full mb-4">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-semibold">Available Devices</CardTitle>
        <Button 
          onClick={isScanning ? stopScan : startScan} 
          variant={isScanning ? "destructive" : "outline"}
          size="sm"
          className="flex items-center space-x-1"
        >
          {isScanning ? (
            <>
              <X className="h-4 w-4 mr-1" />
              Stop
            </>
          ) : (
            <>
              <RefreshCw className={`h-4 w-4 mr-1 ${isScanning ? 'animate-spin' : ''}`} />
              Scan
            </>
          )}
        </Button>
      </CardHeader>
      <CardContent>
        {isScanning && devices.length === 0 && (
          <div className="flex flex-col items-center justify-center py-6 text-center">
            <Loader2 className="h-10 w-10 animate-spin text-bluetooth-dark mb-2" />
            <p className="text-muted-foreground">Scanning for ESP32 devices...</p>
          </div>
        )}

        {!isScanning && devices.length === 0 && (
          <div className="flex flex-col items-center justify-center py-6 text-center">
            <Bluetooth className="h-10 w-10 text-muted-foreground mb-2" />
            <p className="text-muted-foreground">No ESP32 devices found</p>
            <Button onClick={startScan} variant="outline" size="sm" className="mt-2">
              Scan Again
            </Button>
          </div>
        )}

        <div className="space-y-2">
          {devices.map((result) => (
            <div
              key={result.device.deviceId}
              className="flex items-center justify-between p-3 rounded-md bg-bluetooth-light border border-bluetooth hover:bg-bluetooth hover:text-white transition-all cursor-pointer"
              onClick={() => handleDeviceSelect(result.device)}
            >
              <div className="flex flex-col">
                <span className="font-medium">
                  {result.device.name || 'Unknown Device'}
                </span>
                <span className="text-xs opacity-75">
                  {result.device.deviceId.substring(0, 12)}...
                </span>
              </div>
              <div className="text-xs px-2 py-1 bg-bluetooth-dark rounded-full text-white">
                RSSI: {result.rssi}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default BluetoothScanner;
