
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

export function MainNav() {
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  // Mock user authentication state - in a real app, this would be managed by a context or state management library
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);
  
  // Check if the user is on a page that should show the nav
  const shouldShowFullNav = location.pathname !== "/login" && location.pathname !== "/signup";
  
  // Check if user is on a protected page that requires login
  const isProtectedPage = location.pathname === "/feedback" || location.pathname === "/preview";
  
  // Mock logout function
  const handleLogout = () => {
    setIsLoggedIn(false);
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    });
    navigate("/");
  };
  
  // Simulates login for demo purposes - in a real app this would be done via auth
  React.useEffect(() => {
    // If user is on the feedback page, assume they're logged in
    setIsLoggedIn(isProtectedPage);
  }, [location.pathname, isProtectedPage]);

  if (!shouldShowFullNav) return null;

  return (
    <header className="bg-background border-b border-border sticky top-0 z-50">
      <div className="container flex items-center justify-between h-16 mx-auto px-4">
        <Link to="/" className="font-bold text-xl flex items-center">
          <span className="neon-text-blue">Tele</span>
          <span className="neon-text-purple">TradeVisuals</span>
        </Link>

        <nav className="hidden md:flex items-center gap-6">
          <Link to="/" className="text-sm font-medium hover:text-primary">
            Home
          </Link>
          <Link to="/feedback" className="text-sm font-medium hover:text-primary">
            Create Feedback
          </Link>
          <Link to="/disclaimer" className="text-sm font-medium hover:text-primary">
            Terms of Service
          </Link>
        </nav>

        <div className="flex items-center gap-4">
          {isLoggedIn ? (
            <Button variant="outline" onClick={handleLogout}>
              Logout
            </Button>
          ) : (
            <>
              <Button variant="outline" asChild>
                <Link to="/login">Login</Link>
              </Button>
              <Button asChild>
                <Link to="/signup">Sign Up</Link>
              </Button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

export default MainNav;
