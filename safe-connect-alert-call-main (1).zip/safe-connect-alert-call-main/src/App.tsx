import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useEffect } from "react";
import LandingPage from "./pages/LandingPage";
import FeedbackCreator from "./pages/FeedbackCreator";
import PreviewDownload from "./pages/PreviewDownload";
import LoginPage from "./pages/LoginPage";
import SignupPage from "./pages/SignupPage";
import DisclaimerPage from "./pages/DisclaimerPage";
import NotFound from "./pages/NotFound";
import MainNav from "./components/MainNav";
import { locationService } from "./services/location.service";
import { audioService } from "./services/audio.service";
import ChatCreator from "./pages/ChatCreator";

const queryClient = new QueryClient();

const App = () => {
  // Initialize services on app load
  useEffect(() => {
    const initializeServices = async () => {
      try {
        // Initialize location service
        await locationService.initialize();
        
        // Initialize audio service
        audioService.initialize();
        
        console.log('Core services initialized at app level');
      } catch (error) {
        console.error('Failed to initialize core services:', error);
      }
    };
    
    initializeServices();
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <div className="min-h-screen bg-background flex flex-col">
            <MainNav />
            <main className="flex-1">
              <Routes>
                <Route path="/" element={<LandingPage />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/signup" element={<SignupPage />} />
                <Route path="/feedback" element={<FeedbackCreator />} />
                <Route path="/chat-creator" element={<ChatCreator />} />
                <Route path="/preview" element={<PreviewDownload />} />
                <Route path="/disclaimer" element={<DisclaimerPage />} />
                {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </main>
          </div>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
